

import Foundation
import UIKit
import Adjust
import Pushwoosh
import AppTrackingTransparency
import AdSupport

class ActualThirdPartyServicesManager {
    
    static let shared = ActualThirdPartyServicesManager()

    // ref default
    let randomArray = (1...10).map { _ in Int.random(in: 1...100) }
    // ref default
}

